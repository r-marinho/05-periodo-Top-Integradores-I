"""API de leitura: expõe MongoDB e Neo4j como JSON para o Grafana (plugin Infinity).

Implementa o contrato de docs/04_contratos_de_api.md. Suba e acesse:
- http://localhost:8000/health
- http://localhost:8000/docs   (Swagger interativo)
"""
from __future__ import annotations

import os

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from neo4j import GraphDatabase
from pymongo import DESCENDING, MongoClient

MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017")
MONGO_DB = os.getenv("MONGO_DB", "cambio")
NEO4J_URI = os.getenv("NEO4J_URI", "bolt://neo4j:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "senhaForte123")

app = FastAPI(title="API de Leitura — Câmbio NoSQL", version="1.0.0")
# CORS liberado: facilita testes diretos no navegador além do proxy do Grafana.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

mongo = MongoClient(MONGO_URI)[MONGO_DB]
neo4j = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))


def _iso(dt) -> str | None:
    """Formata datetime em ISO-8601 com 'Z' (UTC), como manda o contrato."""
    if not dt:
        return None
    return dt.isoformat().replace("+00:00", "Z")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/mongo/serie")
def mongo_serie(par: str = Query(..., description="Ex.: USD-BRL")):
    """Série temporal de um par (painel de linha do tempo)."""
    cursor = (
        mongo.cotacoes.find(
            {"par": par},
            {"_id": 0, "coletado_em": 1, "compra": 1, "venda": 1},
        )
        .sort("coletado_em", 1)
    )
    return [
        {"coletado_em": _iso(d["coletado_em"]), "compra": d["compra"], "venda": d["venda"]}
        for d in cursor
    ]


@app.get("/mongo/resumo")
def mongo_resumo():
    """Última cotação de cada par (cards e tabela)."""
    pipeline = [
        {"$sort": {"coletado_em": DESCENDING}},
        {"$group": {"_id": "$par", "doc": {"$first": "$$ROOT"}}},
        {"$replaceRoot": {"newRoot": "$doc"}},
        {"$sort": {"par": 1}},
    ]
    saida = []
    for d in mongo.cotacoes.aggregate(pipeline):
        saida.append(
            {
                "par": d["par"],
                "compra": d["compra"],
                "venda": d["venda"],
                "variacao_pct": d.get("variacao_pct"),
                "maxima": d.get("maxima"),
                "minima": d.get("minima"),
                "coletado_em": _iso(d["coletado_em"]),
            }
        )
    return saida


@app.get("/neo4j/grafo")
def neo4j_grafo():
    """Nós-moeda e arestas de conversão, no formato do painel Node Graph."""
    nodes_res, _, _ = neo4j.execute_query(
        "MATCH (m:Moeda) RETURN m.codigo AS id", database_="neo4j"
    )
    edges_res, _, _ = neo4j.execute_query(
        "MATCH (a:Moeda)-[r:CONVERTE]->(b:Moeda) "
        "RETURN a.codigo AS source, b.codigo AS target, r.taxa AS taxa",
        database_="neo4j",
    )
    nodes = [{"id": r["id"], "title": r["id"]} for r in nodes_res]
    edges = [
        {
            "id": f'{r["source"]}-{r["target"]}',
            "source": r["source"],
            "target": r["target"],
            "mainStat": r["taxa"],
        }
        for r in edges_res
    ]
    return {"nodes": nodes, "edges": edges}


@app.get("/neo4j/caminho")
def neo4j_caminho(de: str = Query(...), para: str = Query(...)):
    """Melhor caminho de conversão entre duas moedas (shortestPath)."""
    de, para = de.upper(), para.upper()
    res, _, _ = neo4j.execute_query(
        """
        MATCH (a:Moeda {codigo:$de}), (b:Moeda {codigo:$para})
        MATCH p = shortestPath( (a)-[:CONVERTE*..6]->(b) )
        RETURN [n IN nodes(p) | n.codigo] AS caminho
        """,
        de=de,
        para=para,
        database_="neo4j",
    )
    if not res:
        raise HTTPException(status_code=404, detail="caminho ou moeda não encontrada")
    caminho = res[0]["caminho"]
    return {"de": de, "para": para, "caminho": caminho, "saltos": len(caminho) - 1}


@app.get("/mongo/deadletter")
def mongo_deadletter():
    """Cotações barradas pelo filtro (para discutir qualidade de dados em aula)."""
    cursor = (
        mongo.dead_letter.find({}, {"_id": 0})
        .sort("rejeitado_em", DESCENDING)
        .limit(100)
    )
    return [
        {
            "motivo": d.get("motivo"),
            "rejeitado_em": _iso(d.get("rejeitado_em")),
            "bruto": d.get("bruto"),
        }
        for d in cursor
    ]
