"""Gravação no Neo4j (banco de GRAFO).

A MESMA cotação que virou documento no Mongo vira aqui uma ARESTA entre dois nós-moeda.
É o modelo bom para RELAÇÃO e CAMINHO: "qual a melhor sequência de conversões de BRL
até JPY?".
"""
from __future__ import annotations

from neo4j import GraphDatabase

from filtros import Cotacao


class CargaNeo4j:
    def __init__(self, uri: str, user: str, password: str) -> None:
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self) -> None:
        self.driver.close()

    def gravar(self, cotacao: Cotacao) -> None:
        # MERGE cria se não existir: evita duplicar moedas e arestas.
        # A "taxa" da aresta é a cotação de compra do par.
        self.driver.execute_query(
            """
            MERGE (origem:Moeda {codigo: $origem})
            MERGE (destino:Moeda {codigo: $destino})
            MERGE (origem)-[r:CONVERTE]->(destino)
            SET r.taxa = $taxa, r.atualizado_em = $ts
            """,
            origem=cotacao.moeda_origem,
            destino=cotacao.moeda_destino,
            taxa=cotacao.compra,
            ts=cotacao.coletado_em.isoformat(),
            database_="neo4j",
        )
