"""Testes do filtro de qualidade. Rode com:  pytest  (dentro de gabarito/ingestor/)"""
from datetime import datetime, timezone

from filtros import parse_cotacao, validar


def _bruto(**override):
    """Item cru da AwesomeAPI no formato do endpoint /last, com overrides opcionais."""
    base = {
        "code": "usd",
        "codein": "brl",
        "name": "Dolar/Real",
        "high": "5.45",
        "low": "5.40",
        "bid": "5.42",
        "ask": "5.43",
        "pctChange": "-0.31",
        "create_date": "2026-06-15 13:00:00",
    }
    base.update(override)
    return base


def test_parse_normaliza_maiusculas_e_tipos():
    c = parse_cotacao(_bruto())
    assert c.par == "USD-BRL"
    assert c.moeda_origem == "USD" and c.moeda_destino == "BRL"
    assert isinstance(c.compra, float) and c.compra == 5.42
    assert c.coletado_em == datetime(2026, 6, 15, 13, 0, tzinfo=timezone.utc)


def test_cotacao_valida_passa():
    ok, motivo = validar(parse_cotacao(_bruto()))
    assert ok and motivo == "ok"


def test_rn01_bid_zero_barra():
    ok, motivo = validar(parse_cotacao(_bruto(bid="0")))
    assert not ok and "compra" in motivo


def test_rn02_variacao_absurda_barra():
    ok, motivo = validar(parse_cotacao(_bruto(pctChange="99")))
    assert not ok and "variacao" in motivo


def test_rn05_maxima_menor_que_minima_barra():
    ok, motivo = validar(parse_cotacao(_bruto(high="5.0", low="5.4")))
    assert not ok and "maxima" in motivo
