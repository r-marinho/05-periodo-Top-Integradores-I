"""Ingestor: coleta da AwesomeAPI -> FILTRO -> grava em Mongo e Neo4j.

Roda em laço infinito, uma coleta a cada INTERVALO_SEGUNDOS. Uma falha de rede não
derruba o serviço: ele apenas pula o ciclo e tenta de novo.
"""
from __future__ import annotations

import os
import time

import requests

from carga_mongo import CargaMongo
from carga_neo4j import CargaNeo4j
from filtros import parse_cotacao, validar

MONGO_URI = os.getenv("MONGO_URI", "mongodb://mongo:27017")
MONGO_DB = os.getenv("MONGO_DB", "cambio")
NEO4J_URI = os.getenv("NEO4J_URI", "bolt://neo4j:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "senhaForte123")
PARES = [p.strip() for p in os.getenv("PARES", "USD-BRL,EUR-BRL").split(",") if p.strip()]
INTERVALO = int(os.getenv("INTERVALO_SEGUNDOS", "300"))

URL_LAST = "https://economia.awesomeapi.com.br/json/last/"


def coletar(pares: list[str]) -> dict:
    """Busca o último valor dos pares. Ex.: .../json/last/USD-BRL,EUR-BRL"""
    url = URL_LAST + ",".join(pares)
    resposta = requests.get(url, timeout=15)
    resposta.raise_for_status()
    return resposta.json()


def ciclo(mongo: CargaMongo, neo4j: CargaNeo4j) -> None:
    try:
        dados = coletar(PARES)
    except requests.RequestException as erro:
        print(f"[ingestor] erro de rede, pulando ciclo: {erro}", flush=True)
        return

    validas = barradas = duplicadas = 0
    for bruto in dados.values():
        # 1) normaliza
        try:
            cotacao = parse_cotacao(bruto)
        except (KeyError, ValueError) as erro:
            mongo.gravar_rejeitada(bruto, f"campos invalidos: {erro}")
            barradas += 1
            continue

        # 2) filtra
        ok, motivo = validar(cotacao)
        if not ok:
            mongo.gravar_rejeitada(bruto, motivo)
            barradas += 1
            continue

        # 3) grava nos dois bancos (Neo4j só se não for duplicata no Mongo)
        if mongo.gravar(cotacao):
            neo4j.gravar(cotacao)
            validas += 1
        else:
            duplicadas += 1

    print(
        f"[ingestor] ciclo: {validas} validas, {barradas} barradas, "
        f"{duplicadas} duplicadas.",
        flush=True,
    )


def main() -> None:
    print("[ingestor] iniciando...", flush=True)
    mongo = CargaMongo(MONGO_URI, MONGO_DB)
    neo4j = CargaNeo4j(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)
    try:
        while True:
            ciclo(mongo, neo4j)
            time.sleep(INTERVALO)
    finally:
        neo4j.close()


if __name__ == "__main__":
    main()
