"""Gravação no MongoDB (banco de DOCUMENTOS).

Aqui cada cotação válida vira um documento na coleção `cotacoes`. É o modelo bom para
SÉRIE TEMPORAL: cada coleta é um registro independente, fácil de agregar por dia/par.
"""
from __future__ import annotations

from datetime import datetime, timezone

from pymongo import ASCENDING, MongoClient
from pymongo.errors import DuplicateKeyError

from filtros import Cotacao


class CargaMongo:
    def __init__(self, uri: str, db: str) -> None:
        self.client = MongoClient(uri)
        self.db = self.client[db]
        self.cotacoes = self.db["cotacoes"]
        self.dead_letter = self.db["dead_letter"]
        # Índice único (par, coletado_em): acelera as consultas de série temporal E
        # garante a RN03 (sem duplicata do mesmo par no mesmo instante).
        self.cotacoes.create_index(
            [("par", ASCENDING), ("coletado_em", ASCENDING)], unique=True
        )

    def gravar(self, cotacao: Cotacao) -> bool:
        """Insere um documento. Retorna False se for duplicata (RN03)."""
        try:
            self.cotacoes.insert_one(cotacao.model_dump())
            return True
        except DuplicateKeyError:
            return False

    def gravar_rejeitada(self, bruto: dict, motivo: str) -> None:
        """Registra na dead-letter o que o filtro barrou (e por quê)."""
        self.dead_letter.insert_one(
            {
                "bruto": bruto,
                "motivo": motivo,
                "rejeitado_em": datetime.now(timezone.utc),
            }
        )
