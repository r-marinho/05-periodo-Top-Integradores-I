"""Filtro de qualidade das cotações (regras de negócio RN01–RN05).

- parse_cotacao: converte o item cru da AwesomeAPI (tudo string) num objeto tipado.
- validar: aplica as regras e devolve (ok, motivo). O que for inválido vai para a
  coleção dead-letter, nunca para a coleção principal.
"""
from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, field_validator

# RN02: variação máxima aceitável por coleta. Acima disso, provável erro de dado.
LIMITE_VARIACAO_PCT = 50.0


class Cotacao(BaseModel):
    """Uma cotação já normalizada (mesma estrutura que vira documento no Mongo)."""

    par: str
    moeda_origem: str
    moeda_destino: str
    compra: float
    venda: float
    maxima: float
    minima: float
    variacao_pct: float
    coletado_em: datetime

    @field_validator("moeda_origem", "moeda_destino")
    @classmethod
    def _maiusculas(cls, valor: str) -> str:
        # RN04: código de moeda sempre em MAIÚSCULAS (chave consistente entre os bancos).
        return valor.upper()


def parse_cotacao(bruto: dict) -> Cotacao:
    """Converte um item cru da AwesomeAPI em uma Cotacao.

    Pode lançar KeyError (campo ausente) ou ValueError (número inválido); quem chama
    deve tratar e mandar para a dead-letter.
    """
    origem = bruto["code"].upper()
    destino = bruto["codein"].upper()
    # A AwesomeAPI envia a data como "AAAA-MM-DD HH:MM:SS". Para a prática, tratamos
    # como UTC — suficiente para os gráficos.
    coletado = datetime.strptime(bruto["create_date"], "%Y-%m-%d %H:%M:%S").replace(
        tzinfo=timezone.utc
    )
    return Cotacao(
        par=f"{origem}-{destino}",
        moeda_origem=origem,
        moeda_destino=destino,
        compra=float(bruto["bid"]),
        venda=float(bruto["ask"]),
        maxima=float(bruto["high"]),
        minima=float(bruto["low"]),
        variacao_pct=float(bruto["pctChange"]),
        coletado_em=coletado,
    )


def validar(cotacao: Cotacao) -> tuple[bool, str]:
    """Aplica as regras de qualidade. Retorna (valido, motivo)."""
    if cotacao.compra <= 0:  # RN01
        return False, "compra (bid) ausente ou <= 0"
    if abs(cotacao.variacao_pct) > LIMITE_VARIACAO_PCT:  # RN02
        return False, f"variacao_pct fora do limite (> {LIMITE_VARIACAO_PCT}%)"
    if cotacao.maxima < cotacao.minima:  # RN05
        return False, "maxima menor que minima"
    return True, "ok"
