# GABARITO — Solução de referência (NÃO distribuir aos alunos)

> Esta pasta é a **solução pronta** da prática "Pipeline de Câmbio com MongoDB + Neo4j +
> Grafana". É um projeto **autônomo e executável**: descompacte, rode e funciona. Use
> como referência para corrigir o trabalho dos alunos e para garantir, antes da aula, que
> o ambiente sobe certo.
>
> **Mantenha fora do material entregue aos alunos.** Para empacotar:
> `zip -r gabarito.zip gabarito/`

## O que já vem implementado

| Parte | Arquivos | O que faz |
|---|---|---|
| Ingestão + filtro + cargas | `ingestor/main.py`, `filtros.py`, `carga_mongo.py`, `carga_neo4j.py` | coleta da AwesomeAPI, aplica RN01–RN05, grava nos dois bancos |
| Testes do filtro | `ingestor/test_filtros.py` | um caso que passa e um que barra por regra |
| API de leitura | `api_leitura/main.py` | todos os endpoints do contrato (`/mongo/*`, `/neo4j/*`) |
| Dashboard | `grafana/provisioning/dashboards/cambio.json` | cards, série temporal, tabela, grafo (Node Graph) e dead-letter |

## Como rodar

```bash
cp .env.example .env
docker compose up --build
```

Depois abra:
- **Grafana:** http://localhost:3000 (dashboard "Câmbio NoSQL — Gabarito", sem login)
- **API:** http://localhost:8000/docs
- **Neo4j Browser:** http://localhost:7474 (usuário `neo4j`, senha do `.env`)

A primeira coleta acontece assim que o ingestor sobe; o histórico no gráfico cresce a
cada `INTERVALO_SEGUNDOS` (5 min por padrão — diminua para ver dados mais rápido em aula).

## Rodar só os testes do filtro

```bash
cd ingestor
pip install -r requirements.txt
pytest -v
```

## Notas técnicas (para o professor)

- A **taxa** da aresta no Neo4j usa a cotação de **compra** (`bid`) do par.
- A RN03 (duplicata) é garantida pelo **índice único** `(par, coletado_em)` no Mongo; o
  Neo4j só recebe a cotação quando o Mongo confirma que não era duplicata.
- O painel **Grafo** usa o painel nativo **Node Graph** com duas consultas Infinity (nós
  e arestas). Se sua versão do Grafana renderizar o grafo vazio, confirme que o ingestor
  já rodou ao menos um ciclo (sem nós, não há grafo) — esse é o motivo mais comum.
- Para encerrar e preservar cota: `docker compose down` e pare o Codespace.
